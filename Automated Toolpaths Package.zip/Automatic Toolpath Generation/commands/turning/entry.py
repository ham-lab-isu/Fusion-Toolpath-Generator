import adsk.core, adsk.fusion, adsk.cam, traceback
import os, time
from ...lib import fusionAddInUtils as futil
from ... import config
app = adsk.core.Application.get()
ui = app.userInterface

# TODO *** Specify the command identity information. ***
CMD_ID = f'{config.COMPANY_NAME}_{config.ADDIN_NAME}_turning'
CMD_NAME = 'Automatic Turning Toolpath Generation'
CMD_Description = 'Automatically generate turning toolpaths based on user input'

# Specify that the command will be promoted to the panel.
IS_PROMOTED = True

# TODO *** Define the location where the command button will be created. ***
# This is done by specifying the workspace, the tab, and the panel, and the 
# command it will be inserted beside. Not providing the command to position it
# will insert it at the end.
WORKSPACE_ID = 'CAMEnvironment'
PANEL_ID = 'CAMScriptsAddinsPanel'
COMMAND_BESIDE_ID = 'ScriptsManagerCommand'

# Resource location for command icons, here we assume a sub folder in this directory named "resources".
ICON_FOLDER = os.path.join(os.path.dirname(os.path.abspath(__file__)), 'resources', '')

# Local list of event handlers used to maintain a reference so
# they are not released and garbage collected.
local_handlers = []


# Executed when add-in is run.
def start():
    # Create a command Definition.
    cmd_def = ui.commandDefinitions.addButtonDefinition(CMD_ID, CMD_NAME, CMD_Description, ICON_FOLDER)

    # Define an event handler for the command created event. It will be called when the button is clicked.
    futil.add_handler(cmd_def.commandCreated, command_created)

    # ******** Add a button into the UI so the user can run the command. ********
    # Get the target workspace the button will be created in.
    workspace = ui.workspaces.itemById(WORKSPACE_ID)

    # Get the panel the button will be created in.
    panel = workspace.toolbarPanels.itemById(PANEL_ID)

    # Create the button command control in the UI after the specified existing command.
    control = panel.controls.addCommand(cmd_def, COMMAND_BESIDE_ID, False)

    # Specify if the command is promoted to the main toolbar. 
    control.isPromoted = IS_PROMOTED


# Executed when add-in is stopped.
def stop():
    # Get the various UI elements for this command
    workspace = ui.workspaces.itemById(WORKSPACE_ID)
    panel = workspace.toolbarPanels.itemById(PANEL_ID)
    command_control = panel.controls.itemById(CMD_ID)
    command_definition = ui.commandDefinitions.itemById(CMD_ID)

    # Delete the button command control
    if command_control:
        command_control.deleteMe()

    # Delete the command definition
    if command_definition:
        command_definition.deleteMe()


# Function that is called when a user clicks the corresponding button in the UI.
# This defines the contents of the command dialog and connects to the command related events.
def command_created(args: adsk.core.CommandCreatedEventArgs):
    # General logging for debug.
    futil.log(f'{CMD_NAME} Command Created Event')

    # https://help.autodesk.com/view/fusion360/ENU/?contextId=CommandInputs
    inputs = args.command.commandInputs

    # TODO Define the dialog for your command by adding different inputs to the command.

    #Selection input to select body
    selectionInput = inputs.addSelectionInput('body_selection','Body for Manufacturing','Select a Body')
    selectionInput.addSelectionFilter('Bodies')

    #Selection input for front face
    faceSelection = inputs.addDropDownCommandInput('face_selection','Side to Machine From', adsk.core.DropDownStyles.TextListDropDownStyle)
    faceSelection.listItems.add('None', True)
    faceSelection.listItems.add('Top', False)
    faceSelection.listItems.add('Front', False)
    faceSelection.listItems.add('Right', False)
    faceSelection.listItems.add('Left', False)
    faceSelection.listItems.add('Back', False)
    faceSelection.listItems.add('Bottom', False)

    #Selection of roughing/finishing passes
    roughingInput = inputs.addBoolValueInput('roughing','Include Roughing Passes', True)
    roughingInput.value = True
    finishingInput = inputs.addBoolValueInput('finishing','Include Finishing Passes', True)
    finishingInput.value = True


    # TODO Connect to the events that are needed by this command.
    futil.add_handler(args.command.execute, command_execute, local_handlers=local_handlers)
    futil.add_handler(args.command.inputChanged, command_input_changed, local_handlers=local_handlers)
    futil.add_handler(args.command.executePreview, command_preview, local_handlers=local_handlers)
    futil.add_handler(args.command.validateInputs, command_validate_input, local_handlers=local_handlers)
    futil.add_handler(args.command.destroy, command_destroy, local_handlers=local_handlers)


# This event handler is called when the user clicks the OK button in the command dialog or 
# is immediately called after the created event not command inputs were created for the dialog.
def command_execute(args: adsk.core.CommandEventArgs):
    # General logging for debug.
    futil.log(f'{CMD_NAME} Command Execute Event')

    # TODO ******************************** Your code here ********************************

    try:

        # Get a reference to your command's inputs.
        inputs = args.command.commandInputs
        bodySelection: adsk.core.SelectionCommandInput = inputs.itemById('body_selection')
        faceSelection: adsk.core.DropDownCommandInput = inputs.itemById('face_selection')
        roughingPasses: adsk.core.BoolValueCommandInput = inputs.itemById('roughing')
        finishingPasses: adsk.core.BoolValueCommandInput = inputs.itemById('finishing')

        ######### Creation of user parameters ##########
        design = adsk.fusion.Design.cast(app.activeDocument.products.itemByProductType("DesignProductType"))
        desUnitsMgr = design.unitsManager

        brepBody: adsk.fusion.BRepBody = bodySelection.selection(0).entity
        face = faceSelection.selectedItem.name

        ######### Creation of Setups #########
        #Prep for setup creation
        cam = adsk.cam.CAM.cast(app.activeDocument.products.itemByProductType("CAMProductType"))
        setups = cam.setups

        desRootOcc: adsk.fusion.Occurrence = cam.designRootOccurrence
        root: adsk.fusion.Component = desRootOcc.component
        xAxis: adsk.fusion.ConstructionAxis = root.xConstructionAxis
        yAxis: adsk.fusion.ConstructionPoint = root.yConstructionAxis
        zAxis: adsk.fusion.ConstructionPoint = root.zConstructionAxis
        yzPlane: adsk.fusion.ConstructionPoint = root.yZConstructionPlane

        setupInput = setups.createInput(adsk.cam.OperationTypes.TurningOperation)

        models = []
        models.append(brepBody)
        setupInput.models = models

        spunParam = setupInput.parameters.itemByName('job_useSpunProfile')
        spunValue: adsk.cam.BooleanParameterValue = spunParam.value
        spunValue.value = True

        #Stock setup
        setupInput.stockMode = adsk.cam.SetupStockModes.FixedCylinderStock
        roundParam = setupInput.parameters.itemByName('job_stockFixedRoundingValue')
        roundParam.expression = '0.5in'      

        #wcs setup
        orientationParam = setupInput.parameters.itemByName('wcs_orientation_mode')
        orientationValue: adsk.cam.ChoiceParameterValue = orientationParam.value
        orientationValue.value = 'axesZX'

        wcsZParam = setupInput.parameters.itemByName('job_rotaryAxis')
        wcsZValue: adsk.cam.CadObjectParameterValue = wcsZParam.value
        if face == 'Top' or face == 'Bottom':
            wcsZValue.value = [zAxis]
            jobAxis = adsk.core.Vector3D.create(0,0,1)
        elif face == 'Front' or face == 'Back':
            wcsZValue.value = [yAxis]
            jobAxis = adsk.core.Vector3D.create(0,1,0)
        elif face == 'Right' or  face == 'Left':
            wcsZValue.value = [xAxis]
            jobAxis = adsk.core.Vector3D.create(1,0,0)

        wcsXParam = setupInput.parameters.itemByName('wcs_orientation_axisX')
        wcsXValue: adsk.cam.CadObjectParameterValue = wcsXParam.value
        if face == 'Top' or face == 'Bottom':
            wcsXValue.value = [xAxis]
        elif face == 'Front' or face == 'Back':
            wcsXValue.value = [xAxis]
        elif face == 'Right' or face == 'Left':
            wcsXValue.value = [yAxis]

        flipXParam = setupInput.parameters.itemByName('wcs_orientation_flipX')
        flipXValue: adsk.cam.BooleanParameterValue = flipXParam.value
        if face == 'Right':
            flipXValue.value = True
        elif face == 'Front':
            flipXValue.value = True

        setupInput.name = 'First Setup'

        setup = setups.add(setupInput)

        #Orienting the wcs correctly

        #Set model position in stock to get accurate comparison data
        offsetTypeParam = setup.parameters.itemByName('job_stockLengthMode')
        offsetTypeParamValue: adsk.cam.ChoiceParameterValue = offsetTypeParam.value
        offsetTypeParamValue.value = 'front'

        #Prep variables for wcs orienting
        wcsOrigin = setup.workCoordinateSystem.getAsCoordinateSystem()[0]
        flipZParam = setup.parameters.itemByName('wcs_orientation_flipZ')
        flipZValue: adsk.cam.BooleanParameterValue = flipZParam.value

        camUnitsMgr = cam.unitsManager

        boundingBox = brepBody.boundingBox
        boundingBoxMin = boundingBox.minPoint
        boundingBoxMax = boundingBox.maxPoint
        if face == 'Top':
            boundingBoxZ = round(boundingBoxMin.z,5)
            wcsZ = round(wcsOrigin.z,5)
            mmWcsZ = round(camUnitsMgr.convert(wcsZ, 'mm', 'cm'),5)
            if boundingBoxZ == wcsZ or boundingBoxZ == mmWcsZ:
                flipZValue.value = True
        elif face == 'Front':
            boundingBoxY = round(boundingBoxMax.y,5)
            wcsY= round(wcsOrigin.y,5)
            mmWcsY = round(camUnitsMgr.convert(wcsY, 'mm', 'cm'),5)
            if boundingBoxY == wcsY or boundingBoxY == mmWcsY:
                flipZValue.value = True
        elif face == 'Right':
            boundingBoxX = round(boundingBoxMin.x,5)
            wcsX = round(wcsOrigin.x,5)
            mmWcsX = round(camUnitsMgr.convert(wcsX, 'mm', 'cm'),5)
            if boundingBoxX == wcsX or boundingBoxX == mmWcsX:
                flipZValue.value = True
        elif face == 'Bottom':
            boundingBoxZ = round(boundingBoxMax.z,5)
            wcsZ = round(wcsOrigin.z,5)
            mmWcsZ = round(camUnitsMgr.convert(wcsZ, 'mm', 'cm'),5)
            if boundingBoxZ == wcsZ or boundingBoxZ == mmWcsZ:
                flipZValue.value = True
        elif face == 'Back':
            boundingBoxY = round(boundingBoxMin.y,5)
            wcsY= round(wcsOrigin.y,5)
            mmWcsY = round(camUnitsMgr.convert(wcsY, 'mm', 'cm'),5)
            if boundingBoxY == wcsY or boundingBoxY == mmWcsY:
                flipZValue.value = True
        elif face == 'Left':
            boundingBoxX = round(boundingBoxMax.x,5)
            wcsX = round(wcsOrigin.x,5)
            mmWcsX = round(camUnitsMgr.convert(wcsX, 'mm', 'cm'),5)
            if boundingBoxX == wcsX or boundingBoxX == mmWcsX:
                flipZValue.value = True    

        #Checks for exact length/diameter values of 0.5 and will add addtional stock
        modelDiameter = setup.parameters.itemByName('job_modelInfoDiameter')
        modelDiameterFloat: adsk.cam.FloatParameterValue = modelDiameter.value
        stockDiameter = setup.parameters.itemByName('job_stockDiameter')
        modelLength = setup.parameters.itemByName('job_modelInfoLength')
        modelLengthFloat: adsk.cam.FloatParameterValue = modelLength.value
        stockLength = setup.parameters.itemByName('job_stockLength')
        modelDims = [modelDiameterFloat.value, modelLengthFloat.value]
        stockDims = [stockDiameter, stockLength]
        for i in range(len(modelDims)):
            modelDimsIn = desUnitsMgr.convert(modelDims[i], 'cm', 'in')
            modelDimsInRound = round(modelDimsIn, 4)
            if modelDimsInRound % 0.5 == 0:
                stockDims[i].expression = stockDims[i].expression + ' + job_stockFixedRoundingValue'

        #Offset from front of setup by 0.02"
        offsetParam = setup.parameters.itemByName('job_stockLengthOffset')
        offsetParam.expression = '0.02 in'
        

        #Prep for template calls
        camManager = adsk.cam.CAMManager.get()
        libraryManager = camManager.libraryManager
        templateLibrary = libraryManager.templateLibrary
        localLib = adsk.cam.LibraryLocations.LocalLibraryLocation
        cloudLib = adsk.cam.LibraryLocations.CloudLibraryLocation

        def getTemplateFromLibrary(templateLibrary: adsk.cam.CAMTemplateLibrary, libLocation: adsk.cam.LibraryLocations, folderName: str, templateNameString: str):
            libraryURL = templateLibrary.urlByLocation(libLocation)
        
            templates = None
            if folderName == "":
                templates = templateLibrary.childTemplates(libraryURL)
            else:
                childFolders = templateLibrary.childFolderURLs(libraryURL)
                pickedFolderURL = None
                for folderURL in childFolders:
                    if folderURL.leafName.lower() == folderName.lower():
                        pickedFolderURL = folderURL
                        break
                templates = templateLibrary.childTemplates(pickedFolderURL)

            pickedTemplate = None
            for template in templates:
                if template.name == templateNameString:
                    return template
        
        def applyTemplate(setupUsed: adsk.cam.Setup, roughingPasses: bool, finishingPasses: bool):
            #Global input variable to apply templates
            templateInput: adsk.cam.CreateFromCAMTemplateInput = adsk.cam.CreateFromCAMTemplateInput.create()
            if roughingPasses == True:
                roughingFolder = setupUsed.folders.addFolder('Roughing Passes')
            if finishingPasses == True:
                finishingFolder = setupUsed.folders.addFolder('Finishing Passes')

            #For non paired setups will call and apply primary roughing/finishing templates based on user selection
            if roughingPasses == True:
                template = getTemplateFromLibrary(templateLibrary, cloudLib, "Automation Templates", "TurnR")
                templateInput.camTemplate = template
                roughingFolder.createFromCAMTemplate2(templateInput)
            if finishingPasses == True:
                template = getTemplateFromLibrary(templateLibrary, cloudLib, "Automation Templates", "TurnF")
                templateInput.camTemplate = template
                finishingFolder.createFromCAMTemplate2(templateInput)

        applyTemplate(setup, roughingPasses.value, finishingPasses.value)

        # Generate toolpaths, make edits, and delete empty toolpaths
        drillDelete = False
        drillCreation = False
        for createdSetup in cam.setups:
            for folder in createdSetup.folders:    
                deleteCounter = 0
                operationTotal = folder.operations.count
                for i in range(operationTotal):
                    
                    operation = folder.operations.item(i-deleteCounter)
                    strategy = operation.strategy

                    if strategy == 'turning_profile_roughing' or strategy == 'turning_profile_finishing':
                        modeParam = operation.parameters.itemByName('turningMode')
                        modeParamValue: adsk.cam.ChoiceParameterValue = modeParam.value
                        if modeParamValue.value == 'inner' and drillDelete == True:
                            operation.deleteMe()
                            deleteCounter = deleteCounter + 1
                            continue

                    cam.generateToolpath(operation)
                    while operation.isGenerating == True:
                        time.sleep(5)
        
                    if operation.strategy == 'drill':
                        if operation.hasToolpath == False:
                            operation.deleteMe()
                            deleteCounter = deleteCounter + 1
                            drillDelete = True
                            continue

                    if operation.hasWarning == True:
                        if operation.warning.find("Empty toolpath.") != -1: 
                            operation.deleteMe()
                            deleteCounter = deleteCounter + 1
                            if strategy == 'drill':
                                drillDelete = True
                        elif operation.warning.find("Toolpath is empty.") != -1:
                            operation.deleteMe()
                            deleteCounter = deleteCounter + 1
                            if strategy == 'drill':
                                drillDelete = True
                        elif operation.warning.find("No holes to drill.") != -1:
                            operation.deleteMe()
                            deleteCounter = deleteCounter + 1
                            drillDelete = True
                        else:
                            continue

        toolLibrary = libraryManager.toolLibraries

        def getToolByDescription(toolLibrary: adsk.cam.ToolLibraries, libLocation: adsk.cam.LibraryLocations, toolDescription: str):
            ''' Return a drilling tool for turning operations '''
            query = toolLibrary.createQuery(libLocation)
            query.criteria.add('tool_description', adsk.core.ValueInput.createByString(toolDescription))

            queryResults = query.execute()

            tool = None
            if len(queryResults) > 0:
                tool = queryResults[0].tool

            return tool

        drillTool = getToolByDescription(toolLibrary, cloudLib, '.75" Indexable')

        def createSimpleDrillOperation(name: str, folder: adsk.cam.CAMFolder, tool: adsk.cam.Tool, holeGroup: adsk.cam.RecognizedHoleGroup, through: bool = False,):
            ''' Create simple drilling operation '''
            input = folder.operations.createInput('drill')
            input.displayName = name
            input.tool = tool
            cycleParam = input.parameters.itemByName('cycleType')
            cycleValue: adsk.cam.ChoiceParameterValue = cycleParam.value
            cycleValue.value = 'drilling'
            if through == True:
                input.parameters.itemByName('drillTipThroughBottom').expression = 'true'
                input.parameters.itemByName('breakThroughDepth').expression = '2 mm'
            
            topHeightParam = input.parameters.itemByName('topHeight_mode')
            topHeightValue: adsk.cam.ChoiceParameterValue = topHeightParam.value
            topHeightValue.value = 'from hole top'

            bottomHeightParam = input.parameters.itemByName('bottomHeight_mode')
            bottomHeightValue: adsk.cam.ChoiceParameterValue = bottomHeightParam.value
            bottomHeightValue.value = 'from hole top'

            bottomHeightOffsetParam = input.parameters.itemByName('bottomHeight_offset')
            bottomHeightOffsetParam.expression = '-tool_fluteLength'
            

            # select the holes faces to drill
            faces: list[adsk.fusion.BRepFace] = []
            for i in range(holeGroup.count):
                hole = holeGroup.item(i)
                segmentCount = hole.segmentCount
                for x in range(segmentCount):
                    segment = hole.segment(x)
                    if segment.holeSegmentType == adsk.cam.HoleSegmentType.HoleSegmentTypeFlat:
                        continue
                    faces.extend(segment.faces)
            holeSelection: adsk.cam.CadObjectParameterValue = input.parameters.itemByName('holeFaces').value
            holeSelection.value = faces

            # add to setup
            drillOperation = folder.operations.add(input)

        recognizedHolesInput = adsk.cam.RecognizedHolesInput.create()
        holeGroups = adsk.cam.RecognizedHoleGroup.recognizeHoleGroupsWithInput([brepBody], recognizedHolesInput)

        holeLocationCheck = False
        holeDiameterCheck = False
      
        drillHoles = []

        for holeGroup in holeGroups:
            holeToCheck = holeGroup.item(0)

            if holeToCheck.axis.isParallelTo(jobAxis) == True:

                #Reference hold diameter sizes in order to determine if should be machined
                topDiam = holeToCheck.topDiameter
                bottomDiam = holeToCheck.bottomDiameter
                topDiamIn = camUnitsMgr.convert(topDiam, 'cm', 'in')
                bottomDiamIn = camUnitsMgr.convert(bottomDiam, 'cm', 'in')

                if topDiamIn >= 0.75 and bottomDiamIn >= 0.75:
                    holeDiameterCheck = True

                #Reference hole location within part to determine if should be machined
                currentWcsOrigin = cam.setups.item(0).workCoordinateSystem.getAsCoordinateSystem()[0]
                holeLocation = holeToCheck.top

                if face == 'Top' or face == 'Bottom':
                    holePoint = round(holeLocation.z, 5)
                    mmWcsPoint = currentWcsOrigin.z
                elif face == 'Left' or face == 'Right':
                    holePoint = round(holeLocation.x, 5)
                    mmWcsPoint = currentWcsOrigin.x
                else:
                    holePoint = round(holeLocation.y, 5)
                    mmWcsPoint = currentWcsOrigin.y

                convertWcsPoint = camUnitsMgr.convert(mmWcsPoint, 'mm', 'cm')
                wcsPoint = round(convertWcsPoint, 5)

                holeStockDifference = round(wcsPoint - holePoint, 5)

                if holeStockDifference == 0.0508 or holeStockDifference == -0.0508:
                    holeLocationCheck = True

                if drillDelete == True and holeDiameterCheck == True and holeLocationCheck == True:
                    drillHoles.append(holeGroup)

        if len(holeGroup) > 0:
            for createdSetup in cam.setups:
                for folder in createdSetup.folders:
                    if folder.name != 'Roughing Passes':
                        continue
                    
                    for i in range(len(drillHoles)):
                        createSimpleDrillOperation('API Drill', folder, drillTool, drillHoles[i])

                        drillOp = folder.operations.itemByName('API Drill')
                        cam.generateToolpath(drillOp)
                        while drillOp.isGenerating == True:
                            time.sleep(5)
                        drillCreation = True

        def createInternalProfiling(name: str, folder: adsk.cam.CAMFolder, tool: adsk.cam.Tool, operation: str):
            '''Create an internal profiling operation'''
            if operation == 'roughing':
                input = folder.operations.createInput('turning_profile_roughing')
            elif operation == 'finishing':
                input = folder.operations.createInput('turning_profile_finishing')
            input.displayName = name
            input.tool = tool

            # Set mode as inner diameter
            turningModeParam = input.parameters.itemByName('turningMode')
            turningModeValue: adsk.cam.ChoiceParameterValue = turningModeParam.value
            turningModeValue.value = 'inner'

            # Set height restrictions
            backModeParam = input.parameters.itemByName('backHeight_mode')
            backModeParamValue: adsk.cam.ChoiceParameterValue = backModeParam.value
            backModeParamValue.value = 'model front'

            backOffsetParam = input.parameters.itemByName('backHeight_offset')
            backOffsetParam.expression = '-1.647 in'

            backLimitParam = input.parameters.itemByName('backLimitMode')
            backLimitParamValue: adsk.cam.ChoiceParameterValue = backLimitParam.value
            backLimitParamValue.value = 'cutting edge'

            # Set inner radius restrictions
            innerRadiusParam = input.parameters.itemByName('innerRadius_mode')
            innerRadiusParamValue: adsk.cam.ChoiceParameterValue = innerRadiusParam.value
            innerRadiusParamValue.value = 'from innermost of'

            innerRadiusModelParam = input.parameters.itemByName('innerRadiusFromInnermost_checkModel')
            innerRadiusModelParamValue: adsk.cam.ChoiceParameterValue = innerRadiusModelParam.value
            innerRadiusModelParamValue.value = 'ignore'

            innerRadiusOffsetParam = input.parameters.itemByName('innerRadius_offset')
            innerRadiusOffsetParam.expression = '(.75/2) * 1in'

            innerClearanceParam = input.parameters.itemByName('innerClearance_mode')
            innerClearanceParamValue: adsk.cam.ChoiceParameterValue = innerClearanceParam.value
            innerClearanceParamValue.value = 'from inner'

            innerClearanceOffsetParam = input.parameters.itemByName('innerClearance_offset')
            innerClearanceOffsetParam.expression = '-0.2 in'

            # Lead out changes if finishing pass 
            if operation == 'finishing':
                sameAsLeadInParam = input.parameters.itemByName('exit_sameAsEntry')
                sameAsLeadInParamValue: adsk.cam.BooleanParameterValue = sameAsLeadInParam.value
                sameAsLeadInParamValue.value = False

                linearLeadOutLengthParam = input.parameters.itemByName('exit_distance')
                linearLeadOutLengthParam.expression = '0.02 in'

                linearLeadOutAngleParam = input.parameters.itemByName('exit_angle')
                linearLeadOutAngleParam.expression = '90 deg'
            
            internalProfiling = folder.operations.add(input)






        if drillCreation == True:
            idTool = getToolByDescription(toolLibrary, cloudLib, 'CCMT060204-UF')

            for setup in cam.setups:
                for folder in setup.folders:
                    if folder.name == 'Roughing Passes':
                        createInternalProfiling('ID Roughing API', folder, idTool, 'roughing')

                        ID_roughOp = folder.operations.itemByName('ID Roughing API')
                        cam.generateToolpath(ID_roughOp)
                        while ID_roughOp.isGenerating == True: 
                            time.sleep(5)
                    if folder.name == 'Finishing Passes':
                        createInternalProfiling('ID Finishing API', folder, idTool, 'finishing')

                        ID_finishOp = folder.operations.itemByName('ID Finishing API')
                        for operation in folder.operations:
                            if operation.strategy == 'turning_part':
                                partOp = operation
                        ID_finishOp.moveBefore(partOp)

                        cam.generateToolpath(ID_finishOp)
                        while ID_finishOp.isGenerating == True:
                            time.sleep(5)





        #Output finish window to the user

        #Get stock information
        stockDiameterValue: adsk.cam.FloatParameterValue = stockDiameter.value
        stockLengthValue: adsk.cam.FloatParameterValue = stockLength.value
        stockDimensions = [stockDiameterValue.value, stockLengthValue.value]
        stockDimensionsReal = []
        for i in range(len(stockDimensions)):
            formattedDimension = camUnitsMgr.formatValue(stockDimensions[i], camUnitsMgr.defaultLengthUnits)
            stockDimensionsReal.append(formattedDimension)

        ui.messageBox("Toolpaths populated and generated. The stock needed measures " + stockDimensionsReal[0] + ' in diameter and ' + stockDimensionsReal[1] + ' in length.')


    except:
        if ui:
            ui.messageBox('Failed:\n{}'.format(traceback.format_exc()))



# This event handler is called when the command needs to compute a new preview in the graphics window.
def command_preview(args: adsk.core.CommandEventArgs):
    #General logging for debug.
    futil.log(f'{CMD_NAME} Command Preview Event')
    inputs = args.command.commandInputs
    


# This event handler is called when the user changes anything in the command dialog
# allowing you to modify values of other inputs based on that change.
def command_input_changed(args: adsk.core.InputChangedEventArgs):
    changed_input = args.input
    inputs = args.inputs

    # General logging for debug.
    futil.log(f'{CMD_NAME} Input Changed Event fired from a change to {changed_input.id}')


# This event handler is called when the user interacts with any of the inputs in the dialog
# which allows you to verify that all of the inputs are valid and enables the OK button.
def command_validate_input(args: adsk.core.ValidateInputsEventArgs):
    # General logging for debug.
    futil.log(f'{CMD_NAME} Validate Input Event')

    inputs = args.inputs
    
    # Verify the validity of the input values. This controls if the OK button is enabled or not.
    valueInput = inputs.itemById('value_input')
    if valueInput.value >= 0:
        args.areInputsValid = True
    else:
        args.areInputsValid = False
        

# This event handler is called when the command terminates.
def command_destroy(args: adsk.core.CommandEventArgs):
    # General logging for debug.
    futil.log(f'{CMD_NAME} Command Destroy Event')

    global local_handlers
    local_handlers = []