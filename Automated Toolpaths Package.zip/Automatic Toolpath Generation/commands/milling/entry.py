import adsk.core, adsk.fusion, adsk.cam, traceback
import os, time
from ...lib import fusionAddInUtils as futil
from ... import config
app = adsk.core.Application.get()
ui = app.userInterface

# TODO *** Specify the command identity information. ***
CMD_ID = f'{config.COMPANY_NAME}_{config.ADDIN_NAME}_cmdDialog'
CMD_NAME = 'Automatic Milling Toolpath Generation'
CMD_Description = 'Automatically generate milling toolpaths based on user input'

# Specify that the command will be promoted to the panel.
IS_PROMOTED = True

# TODO *** Define the location where the command button will be created. ***
# This is done by specifying the workspace, the tab, and the panel, and the 
# command it will be inserted beside. Not providing the command to position it
# will insert it at the end.
WORKSPACE_ID = 'CAMEnvironment'
PANEL_ID = 'CAMScriptsAddinsPanel'
COMMAND_BESIDE_ID = 'ScriptsManagerCommand'

# Resource location for command icons, here we assume a sub folder in this directory named "resources".
ICON_FOLDER = os.path.join(os.path.dirname(os.path.abspath(__file__)), 'resources', '')

# Local list of event handlers used to maintain a reference so
# they are not released and garbage collected.
local_handlers = []


# Executed when add-in is run.
def start():
    # Create a command Definition.
    cmd_def = ui.commandDefinitions.addButtonDefinition(CMD_ID, CMD_NAME, CMD_Description, ICON_FOLDER)

    # Define an event handler for the command created event. It will be called when the button is clicked.
    futil.add_handler(cmd_def.commandCreated, command_created)

    # ******** Add a button into the UI so the user can run the command. ********
    # Get the target workspace the button will be created in.
    workspace = ui.workspaces.itemById(WORKSPACE_ID)

    # Get the panel the button will be created in.
    panel = workspace.toolbarPanels.itemById(PANEL_ID)

    # Create the button command control in the UI after the specified existing command.
    # control = panel.controls.addCommand(cmd_def, COMMAND_BESIDE_ID, False)
    control = panel.controls.addCommand(cmd_def)

    # Specify if the command is promoted to the main toolbar. 
    control.isPromoted = IS_PROMOTED


# Executed when add-in is stopped.
def stop():
    # Get the various UI elements for this command
    workspace = ui.workspaces.itemById(WORKSPACE_ID)
    panel = workspace.toolbarPanels.itemById(PANEL_ID)
    command_control = panel.controls.itemById(CMD_ID)
    command_definition = ui.commandDefinitions.itemById(CMD_ID)

    # Delete the button command control
    if command_control:
        command_control.deleteMe()

    # Delete the command definition
    if command_definition:
        command_definition.deleteMe()


# Function that is called when a user clicks the corresponding button in the UI.
# This defines the contents of the command dialog and connects to the command related events.
def command_created(args: adsk.core.CommandCreatedEventArgs):
    # General logging for debug.
    futil.log(f'{CMD_NAME} Command Created Event')

    # https://help.autodesk.com/view/fusion360/ENU/?contextId=CommandInputs
    inputs = args.command.commandInputs

    # TODO Define the dialog for your command by adding different inputs to the command.

    #Selection input to select body
    bodySelectionInput = inputs.addSelectionInput('body_selection','Body for Manufacturing','Select a Body')
    bodySelectionInput.addSelectionFilter('Bodies')

    #Slider input for # of setups
    setupsInput = inputs.addIntegerSliderCommandInput('setup_input','Number of Setups',1,6)
    
    #Boolian input for setup pairing
    pairing = inputs.addBoolValueInput('setup_pairing','Setup pairing',True)
    pairing.value = True

    ############Group inputs for setups#############
    
    #Pair setup 1
    setupP1 = inputs.addGroupCommandInput('setupP1','First Setup Pair')
    setupP1.isExpanded = True
    setupP1.isVisible = False
    setupP1Inputs = setupP1.children
    setupP1dd = setupP1Inputs.addDropDownCommandInput('dd_setupP1','First Machined Side', adsk.core.DropDownStyles.TextListDropDownStyle)
    setupP1ddItems =setupP1dd.listItems
    setupP1None = setupP1ddItems.add('None', True)
    setupP1Top = setupP1ddItems.add('Top', False)
    setupP1Front = setupP1ddItems.add('Front', False)
    setupP1Right = setupP1ddItems.add('Right', False)
    setupP1Left = setupP1ddItems.add('Left', False)
    setupP1Back = setupP1ddItems.add('Back', False)
    setupP1Bottom = setupP1ddItems.add('Bottom', False)
    
    setupP1Roughing1 = setupP1Inputs.addBoolValueInput('setupP1_roughing1', 'Include Roughing Passes First Setup', True)
    setupP1Roughing1.value = True

    setupP1Finishing1 = setupP1Inputs.addBoolValueInput('setupP1_finishing1', 'Include Finishing Passes First Setup', True)
    setupP1Finishing1.value = True

    setupP1Roughing2 = setupP1Inputs.addBoolValueInput('setupP1_roughing2', 'Include Roughing Passes Second Setup', True)
    setupP1Roughing2.value = True

    setupP1Finishing2 = setupP1Inputs.addBoolValueInput('setupP1_finishing2', 'Include Finishing Passes Second Setup', True)
    setupP1Finishing2.value = True

    #Pair setup 2
    setupP2 = inputs.addGroupCommandInput('setupP2','Second Setup Pair')
    setupP2.isExpanded = True
    setupP2.isVisible = False
    setupP2Inputs = setupP2.children
    setupP2dd = setupP2Inputs.addDropDownCommandInput('dd_setupP2','First Machined Side', adsk.core.DropDownStyles.TextListDropDownStyle)
    setupP2ddItems =setupP2dd.listItems
    setupP2None = setupP2ddItems.add('None', True)
    setupP2Top = setupP2ddItems.add('Top', False)
    setupP2Front = setupP2ddItems.add('Front', False)
    setupP2Right = setupP2ddItems.add('Right', False)
    setupP2Left = setupP2ddItems.add('Left', False)
    setupP2Back = setupP2ddItems.add('Back', False)
    setupP2Bottom = setupP2ddItems.add('Bottom', False)
    
    setupP2Roughing1 = setupP2Inputs.addBoolValueInput('setupP2_roughing1', 'Include Roughing Passes First Setup', True)
    setupP2Roughing1.value = True
    
    setupP2Finishing1 = setupP2Inputs.addBoolValueInput('setupP2_finishing1', 'Include Finishing Passes First Setup', True)
    setupP2Finishing1.value = True
    
    setupP2Roughing2 = setupP2Inputs.addBoolValueInput('setupP2_roughing2', 'Include Roughing Passes Second Setup', True)
    setupP2Roughing2.value = True
    
    setupP2Finishing2 = setupP2Inputs.addBoolValueInput('setupP2_finishing2', 'Include Finishing Passes Second Setup', True)
    setupP2Finishing2.value = True

    #Pair setup 3
    setupP3 = inputs.addGroupCommandInput('setupP3','Third Setup Pair')
    setupP3.isExpanded = True
    setupP3.isVisible = False
    setupP3Inputs = setupP3.children
    setupP3dd = setupP3Inputs.addDropDownCommandInput('dd_setupP3','First Machined Side', adsk.core.DropDownStyles.TextListDropDownStyle)
    setupP3ddItems =setupP3dd.listItems
    setupP3None = setupP3ddItems.add('None', True)
    setupP3Top = setupP3ddItems.add('Top', False)
    setupP3Front = setupP3ddItems.add('Front', False)
    setupP3Right = setupP3ddItems.add('Right', False)
    setupP3Left = setupP3ddItems.add('Left', False)
    setupP3Back = setupP3ddItems.add('Back', False)
    setupP3Bottom = setupP3ddItems.add('Bottom', False)
    
    setupP3Roughing1 = setupP3Inputs.addBoolValueInput('setupP3_roughing1', 'Include Roughing Passes First Setup', True)
    setupP3Roughing1.value = True
    
    setupP3Finishing1 = setupP3Inputs.addBoolValueInput('setupP3_finishing1', 'Include Finishing Passes First Setup', True)
    setupP3Finishing1.value = True

    setupP3Roughing2 = setupP3Inputs.addBoolValueInput('setupP3_roughing2', 'Include Roughing Passes Second Setup', True)
    setupP3Roughing2.value = True

    setupP3Finishing2 = setupP3Inputs.addBoolValueInput('setupP3_finishing2', 'Include Finishing Passes Second Setup', True)
    setupP3Finishing2.value = True
    
    #First setup no pairing
    setup1 = inputs.addGroupCommandInput('setup1','First Setup')
    setup1.isExpanded = True
    setup1.isVisible = True
    setup1Inputs = setup1.children
    setup1dd = setup1Inputs.addDropDownCommandInput('dd_setup1','Machined Side', adsk.core.DropDownStyles.TextListDropDownStyle)
    setup1ddItems =setup1dd.listItems
    setup1None = setup1ddItems.add('None', True)
    setup1Top = setup1ddItems.add('Top', False)
    setup1Front = setup1ddItems.add('Front', False)
    setup1Right = setup1ddItems.add('Right', False)
    setup1Left = setup1ddItems.add('Left', False)
    setup1Back = setup1ddItems.add('Back', False)
    setup1Bottom = setup1ddItems.add('Bottom', False)
    
    setup1Roughing = setup1Inputs.addBoolValueInput('setup1_roughing', 'Include Roughing Passes', True)
    setup1Roughing.value = True
    
    setup1Finishing = setup1Inputs.addBoolValueInput('setup1_finishing', 'Include Finishing Passes', True)
    setup1Finishing.value = True

    #Second setup no pairing
    setup2 = inputs.addGroupCommandInput('setup2','Second Setup')
    setup2.isExpanded = True
    setup2.isVisible = False
    setup2Inputs = setup2.children
    setup2dd = setup2Inputs.addDropDownCommandInput('dd_setup2','Machined Side', adsk.core.DropDownStyles.TextListDropDownStyle)
    setup2ddItems =setup2dd.listItems
    setup2None = setup2ddItems.add('None', True)
    setup2Top = setup2ddItems.add('Top', False)
    setup2Front = setup2ddItems.add('Front', False)
    setup2Right = setup2ddItems.add('Right', False)
    setup2Left = setup2ddItems.add('Left', False)
    setup2Back = setup2ddItems.add('Back', False)
    setup2Bottom = setup2ddItems.add('Bottom', False)
    
    setup2Roughing = setup2Inputs.addBoolValueInput('setup2_roughing', 'Include Roughing Passes', True)
    setup2Roughing.value = True
    
    setup2Finishing = setup2Inputs.addBoolValueInput('setup2_finishing', 'Include Finishing Passes', True)
    setup2Finishing.value = True

    #Third setup no pairing
    setup3 = inputs.addGroupCommandInput('setup3','Third Setup')
    setup3.isExpanded = True
    setup3.isVisible = False
    setup3Inputs = setup3.children
    setup3dd = setup3Inputs.addDropDownCommandInput('dd_setup3','Machined Side', adsk.core.DropDownStyles.TextListDropDownStyle)
    setup3ddItems =setup3dd.listItems
    setup3None = setup3ddItems.add('None', True)
    setup3Top = setup3ddItems.add('Top', False)
    setup3Front = setup3ddItems.add('Front', False)
    setup3Right = setup3ddItems.add('Right', False)
    setup3Left = setup3ddItems.add('Left', False)
    setup3Back = setup3ddItems.add('Back', False)
    setup3Bottom = setup3ddItems.add('Bottom', False)
    
    setup3Roughing = setup3Inputs.addBoolValueInput('setup3_roughing', 'Include Roughing Passes', True)
    setup3Roughing.value = True
    
    setup3Finishing = setup3Inputs.addBoolValueInput('setup3_finishing', 'Include Finishing Passes', True)
    setup3Finishing.value = True

    #Fourth setup no pairing
    setup4 = inputs.addGroupCommandInput('setup4','Fourth Setup')
    setup4.isExpanded = True
    setup4.isVisible = False
    setup4Inputs = setup4.children
    setup4dd = setup4Inputs.addDropDownCommandInput('dd_setup4','Machined Side', adsk.core.DropDownStyles.TextListDropDownStyle)
    setup4ddItems =setup4dd.listItems
    setup4None = setup4ddItems.add('None', True)
    setup4Top = setup4ddItems.add('Top', False)
    setup4Front = setup4ddItems.add('Front', False)
    setup4Right = setup4ddItems.add('Right', False)
    setup4Left = setup4ddItems.add('Left', False)
    setup4Back = setup4ddItems.add('Back', False)
    setup4Bottom = setup4ddItems.add('Bottom', False)
    
    setup4Roughing = setup4Inputs.addBoolValueInput('setup4_roughing', 'Include Roughing Passes', True)
    setup4Roughing.value = True
    
    setup4Finishing = setup4Inputs.addBoolValueInput('setup4_finishing', 'Include Finishing Passes', True)
    setup4Finishing.value = True

    #Fifth setup no pairing
    setup5 = inputs.addGroupCommandInput('setup5','Fifth Setup')
    setup5.isExpanded = True
    setup5.isVisible = False
    setup5Inputs = setup5.children
    setup5dd = setup5Inputs.addDropDownCommandInput('dd_setup5','Machined Side', adsk.core.DropDownStyles.TextListDropDownStyle)
    setup5ddItems =setup5dd.listItems
    setup5None = setup5ddItems.add('None', True)
    setup5Top = setup5ddItems.add('Top', False)
    setup5Front = setup5ddItems.add('Front', False)
    setup5Right = setup5ddItems.add('Right', False)
    setup5Left = setup5ddItems.add('Left', False)
    setup5Back = setup5ddItems.add('Back', False)
    setup5Bottom = setup5ddItems.add('Bottom', False)
    
    setup5Roughing = setup5Inputs.addBoolValueInput('setup5_roughing', 'Include Roughing Passes', True)
    setup5Roughing.value = True
    
    setup5Finishing = setup5Inputs.addBoolValueInput('setup5_finishing', 'Include Finishing Passes', True)
    setup5Finishing.value = True

    #Sixth setup no pairing
    setup6 = inputs.addGroupCommandInput('setup6','Sixth Setup')
    setup6.isExpanded = True
    setup6.isVisible = False
    setup6Inputs = setup6.children
    setup6dd = setup6Inputs.addDropDownCommandInput('dd_setup6','Machined Side', adsk.core.DropDownStyles.TextListDropDownStyle)
    setup6ddItems =setup6dd.listItems
    setup6None = setup6ddItems.add('None', True)
    setup6Top = setup6ddItems.add('Top', False)
    setup6Front = setup6ddItems.add('Front', False)
    setup6Right = setup6ddItems.add('Right', False)
    setup6Left = setup6ddItems.add('Left', False)
    setup6Back = setup6ddItems.add('Back', False)
    setup6Bottom = setup6ddItems.add('Bottom', False)
    
    setup6Roughing = setup6Inputs.addBoolValueInput('setup6_roughing', 'Include Roughing Passes', True)
    setup6Roughing.value = True
    
    setup6Finishing = setup6Inputs.addBoolValueInput('setup6_finishing', 'Include Finishing Passes', True)
    setup6Finishing.value = True
    

    # TODO Connect to the events that are needed by this command.
    futil.add_handler(args.command.execute, command_execute, local_handlers=local_handlers)
    futil.add_handler(args.command.inputChanged, command_input_changed, local_handlers=local_handlers)
    futil.add_handler(args.command.executePreview, command_preview, local_handlers=local_handlers)
    futil.add_handler(args.command.validateInputs, command_validate_input, local_handlers=local_handlers)
    futil.add_handler(args.command.destroy, command_destroy, local_handlers=local_handlers)


# This event handler is called when the user clicks the OK button in the command dialog or 
# is immediately called after the created event not command inputs were created for the dialog.
def command_execute(args: adsk.core.CommandEventArgs):
    # General logging for debug.
    futil.log(f'{CMD_NAME} Command Execute Event')

    # TODO ******************************** Your code here ********************************

    ui = None
    try:

        ui = app.userInterface
        # Get a reference to your command's inputs.
        inputs = args.command.commandInputs
        bodySelection: adsk.core.SelectionCommandInput = inputs.itemById('body_selection')
        totalSetups: adsk.core.IntegerSliderCommandInput = inputs.itemById('setup_input')
        setupPairing: adsk.core.BoolValueCommandInput = inputs.itemById('setup_pairing')

        sideSelections = []

        setup1: adsk.core.GroupCommandInput = inputs.itemById('setup1')
        setup1dd: adsk.core.DropDownCommandInput = setup1.children.itemById('dd_setup1')
        setup1Side = setup1dd.selectedItem.name
        sideSelections.append(setup1Side)
        setup1Roughing: adsk.core.BoolValueCommandInput = setup1.children.itemById('setup1_roughing')
        setup1Finishing: adsk.core.BoolValueCommandInput = setup1.children.itemById('setup1_finishing')
        
        setup2: adsk.core.GroupCommandInput = inputs.itemById('setup2')
        setup2dd: adsk.core.DropDownCommandInput = setup2.children.itemById('dd_setup2')
        setup2Side = setup2dd.selectedItem.name
        sideSelections.append(setup2Side)
        setup2Roughing: adsk.core.BoolValueCommandInput = setup2.children.itemById('setup2_roughing')
        setup2Finishing: adsk.core.BoolValueCommandInput = setup2.children.itemById('setup2_finishing')
        
        setup3: adsk.core.GroupCommandInput = inputs.itemById('setup3')
        setup3dd: adsk.core.DropDownCommandInput = setup3.children.itemById('dd_setup3')
        setup3Side = setup3dd.selectedItem.name
        sideSelections.append(setup3Side)
        setup3Roughing: adsk.core.BoolValueCommandInput = setup3.children.itemById('setup3_roughing')
        setup3Finishing: adsk.core.BoolValueCommandInput = setup3.children.itemById('setup3_finishing')

        setup4: adsk.core.GroupCommandInput = inputs.itemById('setup4')
        setup4dd: adsk.core.DropDownCommandInput = setup4.children.itemById('dd_setup4')
        setup4Side = setup4dd.selectedItem.name
        sideSelections.append(setup4Side)
        setup4Roughing: adsk.core.BoolValueCommandInput = setup4.children.itemById('setup4_roughing')
        setup4Finishing: adsk.core.BoolValueCommandInput = setup4.children.itemById('setup4_finishing')

        setup5: adsk.core.GroupCommandInput = inputs.itemById('setup5')
        setup5dd: adsk.core.DropDownCommandInput = setup5.children.itemById('dd_setup5')
        setup5Side = setup5dd.selectedItem.name
        sideSelections.append(setup5Side)
        setup5Roughing: adsk.core.BoolValueCommandInput = setup5.children.itemById('setup5_roughing')
        setup5Finishing: adsk.core.BoolValueCommandInput = setup5.children.itemById('setup5_finishing')

        setup6: adsk.core.GroupCommandInput = inputs.itemById('setup6')
        setup6dd: adsk.core.DropDownCommandInput = setup6.children.itemById('dd_setup6')
        setup6Side = setup6dd.selectedItem.name
        sideSelections.append(setup6Side)
        setup6Roughing: adsk.core.BoolValueCommandInput = setup6.children.itemById('setup6_roughing')
        setup6Finishing: adsk.core.BoolValueCommandInput = setup6.children.itemById('setup6_finishing')

        setupP1: adsk.core.GroupCommandInput = inputs.itemById('setupP1')
        setupP1dd: adsk.core.DropDownCommandInput = setupP1.children.itemById('dd_setupP1')
        setupP1Side1 = setupP1dd.selectedItem.name
        sideSelections.append(setupP1Side1)
        #Account for "unselected" pair side
        if setupP1Side1 != 'None':
            if setupP1Side1 == 'Top':
                setupP1Side2 = 'Bottom'
            if setupP1Side1 == 'Front':
                setupP1Side2 = 'Back'
            if setupP1Side1 == 'Right':
                setupP1Side2 = 'Left'
            if setupP1Side1 == 'Left':
                setupP1Side2 = 'Right'
            if setupP1Side1 == 'Back':
                setupP1Side2 = 'Front'
            if setupP1Side1 == 'Bottom':
                setupP1Side2 = 'Top'
            sideSelections.append(setupP1Side2)
        setupP1Roughing1: adsk.core.BoolValueCommandInput = setupP1.children.itemById('setupP1_roughing1')
        setupP1Finishing1: adsk.core.BoolValueCommandInput = setupP1.children.itemById('setupP1_finishing1')
        setupP1Roughing2: adsk.core.BoolValueCommandInput = setupP1.children.itemById('setupP1_roughing2')
        setupP1Finishing2: adsk.core.BoolValueCommandInput = setupP1.children.itemById('setupP1_finishing2')

        setupP2: adsk.core.GroupCommandInput = inputs.itemById('setupP2')
        setupP2dd: adsk.core.DropDownCommandInput = setupP2.children.itemById('dd_setupP2')
        setupP2Side1 = setupP2dd.selectedItem.name
        sideSelections.append(setupP2Side1)
        if setupP2Side1 != 'None':
            if setupP2Side1 == 'Top':
                setupP2Side2 = 'Bottom'
            if setupP2Side1 == 'Front':
                setupP2Side2 = 'Back'
            if setupP2Side1 == 'Right':
                setupP2Side2 = 'Left'
            if setupP2Side1 == 'Left':
                setupP2Side2 = 'Right'
            if setupP2Side1 == 'Back':
                setupP2Side2 = 'Front'
            if setupP2Side1 == 'Bottom':
                setupP2Side2 = 'Top'
            sideSelections.append(setupP2Side2)
        setupP2Roughing1: adsk.core.BoolValueCommandInput = setupP2.children.itemById('setupP2_roughing1')
        setupP2Finishing1: adsk.core.BoolValueCommandInput = setupP2.children.itemById('setupP2_finishing1')
        setupP2Roughing2: adsk.core.BoolValueCommandInput = setupP2.children.itemById('setupP2_roughing2')
        setupP2Finishing2: adsk.core.BoolValueCommandInput = setupP2.children.itemById('setupP2_finishing2')

        setupP3: adsk.core.GroupCommandInput = inputs.itemById('setupP3')
        setupP3dd: adsk.core.DropDownCommandInput = setupP3.children.itemById('dd_setupP3')
        setupP3Side1 = setupP3dd.selectedItem.name
        sideSelections.append(setupP3Side1)
        if setupP3Side1 != 'None':
            if setupP3Side1 == 'Top':
                setupP3Side2 = 'Bottom'
            if setupP3Side1 == 'Front':
                setupP3Side2 = 'Back'
            if setupP3Side1 == 'Right':
                setupP3Side2 = 'Left'
            if setupP3Side1 == 'Left':
                setupP3Side2 = 'Right'
            if setupP3Side1 == 'Back':
                setupP3Side2 = 'Front'
            if setupP3Side1 == 'Bottom':
                setupP3Side2 = 'Top'
            sideSelections.append(setupP3Side2)
        setupP3Roughing1: adsk.core.BoolValueCommandInput = setupP3.children.itemById('setupP3_roughing1')
        setupP3Finishing1: adsk.core.BoolValueCommandInput = setupP3.children.itemById('setupP3_finishing1')
        setupP3Roughing2: adsk.core.BoolValueCommandInput = setupP3.children.itemById('setupP3_roughing2')
        setupP3Finishing2: adsk.core.BoolValueCommandInput = setupP3.children.itemById('setupP3_finishing2')
    
        setupSides = []
        for i in range(len(sideSelections)):
            if sideSelections[i] != 'None':
                setupSides.append(sideSelections[i])

        ######### Creation of user parameters ##########
        design = adsk.fusion.Design.cast(app.activeDocument.products.itemByProductType("DesignProductType"))

        #Creation of bounding box and obtaining size data
        brepBody: adsk.fusion.BRepBody = bodySelection.selection(0).entity
        bBox = brepBody.boundingBox
        bBoxMax = bBox.maxPoint.asArray()
        bBoxMin = bBox.minPoint.asArray()
        limits = []
        for i in range(len(bBoxMax)):
            limits.append(bBoxMax[i] - bBoxMin[i])
        
        #unit conversion
        unitsMgr = design.unitsManager    
        values = []
        for i in range(len(limits)):
            values.append(unitsMgr.formatValue(limits[i]))


        #check for exisiting user parameters and delete
        oldUPLength = design.userParameters.itemByName('ModelLength')
        if oldUPLength is not None:
            oldUPLength.deleteMe()
        oldUPWidth = design.userParameters.itemByName('ModelWidth')
        if oldUPWidth is not None:
            oldUPWidth.deleteMe()
        oldUPHeight = design.userParameters.itemByName('ModelHeight')
        if oldUPHeight is not None:
            oldUPHeight.deleteMe()

        #creation of user parameters
        realLength = adsk.core.ValueInput.createByString(values[0])
        design.userParameters.add('ModelLength',realLength,unitsMgr.defaultLengthUnits,"Length of model bounding box")
        realWidth = adsk.core.ValueInput.createByString(values[1])
        design.userParameters.add('ModelWidth',realWidth,unitsMgr.defaultLengthUnits,"Width of model bounding box")
        realHeight = adsk.core.ValueInput.createByString(values[2])
        design.userParameters.add('ModelHeight',realHeight,unitsMgr.defaultLengthUnits,"Height of model bounding box")    


        ######### Creation of Setups #########
        #Prep for setup creation
        cam = adsk.cam.CAM.cast(app.activeDocument.products.itemByProductType("CAMProductType"))
        setups = cam.setups

        desRootOcc: adsk.fusion.Occurrence = cam.designRootOccurrence
        root: adsk.fusion.Component = desRootOcc.component
        xAxis: adsk.fusion.ConstructionPoint = root.xConstructionAxis
        yAxis: adsk.fusion.ConstructionPoint = root.yConstructionAxis
        zAxis: adsk.fusion.ConstructionPoint = root.zConstructionAxis

        def setup_creator(setupNumber: int, machineSideSelection: str):
            setupInput = setups.createInput(adsk.cam.OperationTypes.MillingOperation)

            models = []
            models.append(brepBody)
            setupInput.models = models

            if setupNumber == 1:
                setupInput.stockMode = adsk.cam.SetupStockModes.FixedBoxStock
                roundParam = setupInput.parameters.itemByName('job_stockFixedRoundingValue')
                roundParam.expression = '.5in'
            else:
                setupInput.stockMode = adsk.cam.SetupStockModes.PreviousSetupStock
                restMachineParam = setupInput.parameters.itemByName('job_continueMachining')
                restMachineValue: adsk.cam.BooleanParameterValue = restMachineParam.value
                restMachineValue.value = True

            originParam = setupInput.parameters.itemByName("wcs_origin_mode")
            choiceVal: adsk.cam.ChoiceParameterValue = originParam.value
            choiceVal.value = 'stockPoint'

            originPoint = setupInput.parameters.itemByName('wcs_origin_boxPoint')
            choiceVal: adsk.cam.ChoiceParameterValue = originPoint.value
            choiceVal.value = 'top center'

            orientationParam = setupInput.parameters.itemByName('wcs_orientation_mode')
            choiceVal: adsk.cam.ChoiceParameterValue = orientationParam.value
            choiceVal.value = 'axesZX'

            if machineSideSelection == 'Top':
                wcsZParam = setupInput.parameters.itemByName('wcs_orientation_axisZ')     
                wcsZValue: adsk.cam.CadObjectParameterValue = wcsZParam.value
                wcsZValue.value = [zAxis]

                flipZParam = setupInput.parameters.itemByName('wcs_orientation_flipZ')
                flipZValue: adsk.cam.ChoiceParameterValue = flipZParam.value
                flipZValue.value = False

                wcsXParam = setupInput.parameters.itemByName('wcs_orientation_axisX')
                wcsXValue: adsk.cam.CadObjectParameterValue = wcsXParam.value
                if values[0] > values[1]:
                    wcsXValue.value = [xAxis]
                else:
                    wcsXValue.value = [yAxis]

            if machineSideSelection == 'Front':
                wcsZParam = setupInput.parameters.itemByName('wcs_orientation_axisZ')     
                wcsZValue: adsk.cam.CadObjectParameterValue = wcsZParam.value
                wcsZValue.value = [yAxis]

                flipZParam = setupInput.parameters.itemByName('wcs_orientation_flipZ')
                flipZValue: adsk.cam.ChoiceParameterValue = flipZParam.value
                flipZValue.value = True

                wcsXParam = setupInput.parameters.itemByName('wcs_orientation_axisX')
                wcsXValue: adsk.cam.CadObjectParameterValue = wcsXParam.value
                if values[2] > values[0]:
                    wcsXValue.value = [zAxis]
                else:
                    wcsXValue.value = [xAxis]

            if machineSideSelection == 'Right':
                wcsZParam = setupInput.parameters.itemByName('wcs_orientation_axisZ')     
                wcsZValue: adsk.cam.CadObjectParameterValue = wcsZParam.value
                wcsZValue.value = [xAxis]

                flipZParam = setupInput.parameters.itemByName('wcs_orientation_flipZ')
                flipZValue: adsk.cam.ChoiceParameterValue = flipZParam.value
                flipZValue.value = False

                wcsXParam = setupInput.parameters.itemByName('wcs_orientation_axisX')
                wcsXValue: adsk.cam.CadObjectParameterValue = wcsXParam.value
                if values[2] > values[1]:
                    wcsXValue.value = [zAxis]
                else:
                    wcsXValue.value = [yAxis]

            if machineSideSelection == 'Left':
                wcsZParam = setupInput.parameters.itemByName('wcs_orientation_axisZ')     
                wcsZValue: adsk.cam.CadObjectParameterValue = wcsZParam.value
                wcsZValue.value = [xAxis]

                flipZParam = setupInput.parameters.itemByName('wcs_orientation_flipZ')
                flipZValue: adsk.cam.ChoiceParameterValue = flipZParam.value
                flipZValue.value = True

                wcsXParam = setupInput.parameters.itemByName('wcs_orientation_axisX')
                wcsXValue: adsk.cam.CadObjectParameterValue = wcsXParam.value
                if values[2] > values[1]:
                    wcsXValue.value = [zAxis]
                else:
                    wcsXValue.value = [yAxis]

            if machineSideSelection == 'Back':
                wcsZParam = setupInput.parameters.itemByName('wcs_orientation_axisZ')     
                wcsZValue: adsk.cam.CadObjectParameterValue = wcsZParam.value
                wcsZValue.value = [yAxis]

                flipZParam = setupInput.parameters.itemByName('wcs_orientation_flipZ')
                flipZValue: adsk.cam.ChoiceParameterValue = flipZParam.value
                flipZValue.value = False

                wcsXParam = setupInput.parameters.itemByName('wcs_orientation_axisX')
                wcsXValue: adsk.cam.CadObjectParameterValue = wcsXParam.value
                if values[2] > values[0]:
                    wcsXValue.value = [zAxis]
                else:
                    wcsXValue.value = [xAxis]

            if machineSideSelection == 'Bottom':
                wcsZParam = setupInput.parameters.itemByName('wcs_orientation_axisZ')     
                wcsZValue: adsk.cam.CadObjectParameterValue = wcsZParam.value
                wcsZValue.value = [zAxis]

                flipZParam = setupInput.parameters.itemByName('wcs_orientation_flipZ')
                flipZValue: adsk.cam.ChoiceParameterValue = flipZParam.value
                flipZValue.value = True

                wcsXParam = setupInput.parameters.itemByName('wcs_orientation_axisX')
                wcsXValue: adsk.cam.CadObjectParameterValue = wcsXParam.value
                if values[0] > values[1]:
                    wcsXValue.value = [xAxis]
                else:
                    wcsXValue.value = [yAxis]
            return setupInput
        
        

        #Prep for template calls
        camManager = adsk.cam.CAMManager.get()
        libraryManager = camManager.libraryManager
        templateLibrary = libraryManager.templateLibrary
        localLib = adsk.cam.LibraryLocations.LocalLibraryLocation
        cloudLib = adsk.cam.LibraryLocations.CloudLibraryLocation

        def getTemplateFromLibrary(templateLibrary: adsk.cam.CAMTemplateLibrary, libLocation: adsk.cam.LibraryLocations, folderName: str, templateNameString: str):
            libraryURL = templateLibrary.urlByLocation(libLocation)
        
            templates = None
            if folderName == "":
                templates = templateLibrary.childTemplates(libraryURL)
            else:
                childFolders = templateLibrary.childFolderURLs(libraryURL)
                pickedFolderURL = None
                for folderURL in childFolders:
                    if folderURL.leafName.lower() == folderName.lower():
                        pickedFolderURL = folderURL
                        break
                templates = templateLibrary.childTemplates(pickedFolderURL)

            pickedTemplate = None
            for template in templates:
                if template.name == templateNameString:
                    return template
        
        def applyTemplate(setupUsed: adsk.cam.Setup, sideSelection: str, roughingPasses: bool, finishingPasses: bool, isPairedSetup: bool):
            #Global input variable to apply templates
            templateInput: adsk.cam.CreateFromCAMTemplateInput = adsk.cam.CreateFromCAMTemplateInput.create()
            if roughingPasses == True:
                roughingFolder = setupUsed.folders.addFolder('Roughing Passes')
            if finishingPasses == True:
                finishingFolder = setupUsed.folders.addFolder('Finishing Passes')

            #For non paired setups will call and apply primary roughing/finishing templates based on user selection
            if isPairedSetup == False:
                if roughingPasses == True:
                    template = getTemplateFromLibrary(templateLibrary, cloudLib, "Automation Templates", "OP1R")
                    templateInput.camTemplate = template
                    roughingFolder.createFromCAMTemplate2(templateInput)
                if finishingPasses == True:
                    template = getTemplateFromLibrary(templateLibrary, cloudLib, "Automation Templates", "OP1F")
                    templateInput.camTemplate = template
                    finishingFolder.createFromCAMTemplate2(templateInput)
            #For paired setups will call and apply secondary roughing/finishing templates based on user selection
            if isPairedSetup == True:
                if roughingPasses == True:
                    template = getTemplateFromLibrary(templateLibrary, cloudLib, "Automation Templates", "OP2R")
                    templateInput.camTemplate = template
                    roughingFolder.createFromCAMTemplate2(templateInput)
                if finishingPasses == True:
                    template = getTemplateFromLibrary(templateLibrary, cloudLib, "Automation Templates", "OP2F")
                    templateInput.camTemplate = template
                    finishingFolder.createFromCAMTemplate2(templateInput)

        createdSetups : list[adsk.cam.Setup] = []
        #Creates setups in the case pairing is turned off
        if setupPairing.value == False:
            for x in range(totalSetups.valueOne):
                if x == 0:
                    setupInput = setup_creator(1, setup1Side)
                    side = setup1Side
                    rough = setup1Roughing.value
                    finish = setup1Finishing.value
                    paired = False
                    setupInput.name = 'First Setup'
                if x == 1:
                    setupInput = setup_creator(2, setup2Side)
                    side = setup2Side
                    rough = setup2Roughing.value
                    finish = setup2Finishing.value
                    paired = False
                    setupInput.name = 'Second Setup'
                if x == 2:
                    setupInput = setup_creator(3, setup3Side)
                    side = setup3Side
                    rough = setup3Roughing.value
                    finish = setup3Finishing.value
                    paired = False
                    setupInput.name = 'Third Setup'
                if x == 3:
                    setupInput = setup_creator(4, setup4Side)
                    side = setup4Side
                    rough = setup4Roughing.value
                    finish = setup4Finishing.value
                    paired = False
                    setupInput.name = 'Fourth Setup'
                if x == 4:
                    setupInput = setup_creator(5, setup5Side)
                    side = setup5Side
                    rough = setup5Roughing.value
                    finish = setup5Finishing.value
                    paired = False
                    setupInput.name = 'Fifth Setup'
                if x == 5:
                    setupInput = setup_creator(6, setup6Side)
                    side = setup6Side
                    rough = setup6Roughing.value
                    finish = setup6Finishing.value
                    paired = False
                    setupInput.name = 'Sixth Setup'
                setup = setups.add(setupInput)
                createdSetups.append(setup)
                
                #Checks for any side lengths that might equal the roudning value and additonally offsets them so there is always extra stock
                if x == 0:
                    xLength = setup.parameters.itemByName('job_modelInfoDimensionX')
                    xFloat: adsk.cam.FloatParameterValue = xLength.value
                    stockX = setup.parameters.itemByName('job_stockFixedX')
                    yLength = setup.parameters.itemByName('job_modelInfoDimensionY')
                    yFloat: adsk.cam.FloatParameterValue = yLength.value
                    stockY = setup.parameters.itemByName('job_stockFixedY')
                    zLength = setup.parameters.itemByName('job_modelInfoDimensionZ')
                    zFloat: adsk.cam.FloatParameterValue = zLength.value
                    stockZ = setup.parameters.itemByName('job_stockFixedZ')
                    lengths = [xFloat.value, yFloat.value, zFloat.value]
                    stockDims = [stockX, stockY, stockZ]
                    for i in range(len(lengths)):
                        lengthInch = unitsMgr.convert(lengths[i], 'cm', 'in')
                        lengthInchRound = round(lengthInch, 4)
                        if lengthInchRound % 0.5 == 0:
                            stockDims[i].expression = stockDims[i].expression + ' + job_stockFixedRoundingValue'
                templateApplied = applyTemplate(setup, side, rough, finish, paired)

        #Creates setups in case pairing is turned on
        if setupPairing.value == True:
            for x in range(totalSetups.valueOne):
                if x == 0:
                    if totalSetups.valueOne == 1:
                        setupInput = setup_creator(1, setup1Side)
                        side = setup1Side
                        rough = setup1Roughing.value
                        finish = setup1Finishing.value
                        paired = False
                    else:
                        setupInput = setup_creator(1, setupP1Side1)
                        side = setupP1Side1
                        rough = setupP1Roughing1.value
                        finish = setupP1Finishing1.value
                        paired = False
                    setupInput.name = 'First Setup'
                if x == 1:
                    setupInput = setup_creator(2, setupP1Side2)
                    side = setupP1Side2
                    rough = setupP1Roughing2.value
                    finish = setupP1Finishing2.value
                    paired = True
                    setupInput.name = 'Second Setup'
                if x == 2:
                    if totalSetups.valueOne == 3:
                        setupInput = setup_creator(3, setup3Side)
                        side = setup3Side
                        rough = setup3Roughing.value
                        finish = setup3Finishing.value
                        paired = False
                    else:
                        setupInput = setup_creator(3, setupP2Side1)
                        side = setupP2Side1
                        rough = setupP2Roughing1.value
                        finish = setupP2Finishing1.value
                        paired = False
                    setupInput.name = 'Third Setup'
                if x == 3:
                    setupInput = setup_creator(4, setupP2Side2)
                    side = setupP2Side2
                    rough = setupP2Roughing2.value
                    finish = setupP2Finishing2.value
                    paired = True
                    setupInput.name = 'Fourth Setup'
                if x == 4:
                    if totalSetups.valueOne == 5:
                        setupInput = setup_creator(5, setup5Side)
                        side = setup5Side
                        rough = setup5Roughing.value
                        finish = setup5Finishing.value
                        paired = False
                    else:
                        setupInput = setup_creator(5, setupP3Side1)
                        side = setupP3Side1
                        rough = setupP3Roughing1.value
                        finish = setupP3Finishing1.value
                        paired = False
                    setupInput.name = 'Fifth Setup'
                if x == 5:
                    setupInput = setup_creator(6, setupP3Side2)
                    side = setupP3Side2
                    rough = setupP3Roughing2.value
                    finish = setupP3Finishing2.value
                    paired = True
                    setupInput.name = 'Sixth Setup'
                setup = setups.add(setupInput)
                
                # Check for rounding of stock size - round up if one dimension is equal to model size
                if x == 0:
                    xLength = setup.parameters.itemByName('job_modelInfoDimensionX')
                    xFloat: adsk.cam.FloatParameterValue = xLength.value
                    stockX = setup.parameters.itemByName('job_stockFixedX')
                    yLength = setup.parameters.itemByName('job_modelInfoDimensionY')
                    yFloat: adsk.cam.FloatParameterValue = yLength.value
                    stockY = setup.parameters.itemByName('job_stockFixedY')
                    zLength = setup.parameters.itemByName('job_modelInfoDimensionZ')
                    zFloat: adsk.cam.FloatParameterValue = zLength.value
                    stockZ = setup.parameters.itemByName('job_stockFixedZ')
                    lengths = [xFloat.value, yFloat.value, zFloat.value]
                    stockDims = [stockX, stockY, stockZ]
                    for i in range(len(lengths)):
                        lengthInch = unitsMgr.convert(lengths[i], 'cm', 'in')
                        lengthInchRound = round(lengthInch, 4)
                        if lengthInchRound % 0.5 == 0:
                            stockDims[i].expression = stockDims[i].expression + ' + job_stockFixedRoundingValue'
                templateApplied = applyTemplate(setup, side, rough, finish, paired)
                
        # Generate toolpaths, make edits, and delete empty toolpaths
        setupCounter = 0
        for createdSetup in cam.setups:
            for folder in createdSetup.folders:    
                deleteCounter = 0
                operationTotal = folder.operations.count
                for i in range(operationTotal):
                    
                    operation = folder.operations.item(i-deleteCounter)
                    
                    # Find and avoid vertical walls on finishing passes - broken bc of new update
                    if operation.strategy == 'steep_and_shallow':
                        # stepdownParam = operation.parameters.itemByName('maximumStepdown')
                        # stepdownParamExpression = stepdownParam.expression
                        # stepdownParamExpression = 'tool_diameter * 0.05'

                        verticalWalls = []

                        bodyFaces = brepBody.faces
                        for face in bodyFaces:
                            normal = face.evaluator.getNormalAtPoint(face.centroid)

                            setupSide = setupSides[setupCounter]
                            if setupSide == 'Top' or setupSide == 'Bottom':
                                normalZ = round(normal[1].z, 10)
                                if normalZ == 0:
                                    verticalWalls.append(face)
                            if setupSide == 'Right' or setupSide == 'Left':
                                normalX = round(normal[1].x, 10)
                                if normalX == 0:
                                    verticalWalls.append(face)
                            if setupSide == 'Front' or setupSide == 'Back':
                                normalY = round(normal[1].y, 10)
                                if normalY == 0:
                                    verticalWalls.append(face)


                        surfaceGroupsParam: adsk.cam.CadMachineAvoidGroupsParameterValue = operation.parameters.itemByName('checkSurfaceSelectionSets').value
                        machineAvoidGroups = surfaceGroupsParam.getMachineAvoidGroups()
                        machineAvoidGroup: adsk.cam.MachineAvoidDirectSelection = machineAvoidGroups.createNewMachineAvoidDirectSelectionGroup()
                        machineAvoidGroup.machineMode = adsk.cam.MachiningMode.Avoid_MachiningMode
                        machineAvoidGroup.radialOffset = .02
                        machineAvoidGroup.axialOffset = .02
                        machineAvoidGroup.inputGeometry = list(verticalWalls)
                        surfaceGroupsParam.applyMachineAvoidGroups(machineAvoidGroups)

                    cam.generateToolpath(operation)
                    while operation.isGenerating == True:
                        time.sleep(5)
                    if operation.hasWarning == True:
                        if operation.warning.find("Empty toolpath.") != -1: 
                            operation.deleteMe()
                            deleteCounter = deleteCounter + 1
                        elif operation.warning.find("Toolpath is empty.") != -1:
                            operation.deleteMe()
                            deleteCounter = deleteCounter + 1
                        else:
                            continue
            setupCounter = setupCounter + 1
                
                    
        
        
        #Output to the user the dimensions of the stock they need
        firstOp = setups.itemByName('First Setup')
        stockXParam = firstOp.parameters.itemByName('job_stockFixedX')
        stockXValue: adsk.cam.FloatParameterValue = stockXParam.value
        stockYParam = firstOp.parameters.itemByName('job_stockFixedY')
        stockYValue: adsk.cam.FloatParameterValue = stockYParam.value
        stockZParam = firstOp.parameters.itemByName('job_stockFixedZ')
        stockZValue: adsk.cam.FloatParameterValue = stockZParam.value
        stockDimensions = [stockXValue.value, stockYValue.value, stockZValue.value]
        stockDimensionsReal = []
        for i in range(3):
            formattedDimension = unitsMgr.formatValue(stockDimensions[i], unitsMgr.defaultLengthUnits)
            stockDimensionsReal.append(formattedDimension)
        ui.messageBox("Toolpaths populated and generated. The stock needed measures " + stockDimensionsReal[0] + ' X ' + stockDimensionsReal[1] + ' X ' + stockDimensionsReal[2])
    

    except:
        if ui:
            ui.messageBox('Failed:\n{}'.format(traceback.format_exc()))

# This event handler is called when the command needs to compute a new preview in the graphics window.
def command_preview(args: adsk.core.CommandEventArgs):
    #General logging for debug.
    futil.log(f'{CMD_NAME} Command Preview Event')
    inputs = args.command.commandInputs
    


# This event handler is called when the user changes anything in the command dialog
# allowing you to modify values of other inputs based on that change.
def command_input_changed(args: adsk.core.InputChangedEventArgs):
    changed_input = args.input
    inputs = args.inputs

    setups : list[adsk.cam.Setup] = []

    #References to inputs in command window
    totalSetups: adsk.core.IntegerSliderCommandInput = inputs.itemById('setup_input')
    setupPairing: adsk.core.BoolValueCommandInput = inputs.itemById('setup_pairing')

    setup1: adsk.core.GroupCommandInput = inputs.itemById('setup1')
    setups.append(setup1)
    setup1dd: adsk.core.DropDownCommandInput = setup1.children.itemById('dd_setup1')
    setup1Side = setup1dd.selectedItem.name

    setup2: adsk.core.GroupCommandInput = inputs.itemById('setup2')
    setups.append(setup2)
    setup2dd: adsk.core.DropDownCommandInput = setup2.children.itemById('dd_setup2')
    setup2Side = setup2dd.selectedItem.name
    
    setup3: adsk.core.GroupCommandInput = inputs.itemById('setup3')
    setups.append(setup3)
    setup3dd: adsk.core.DropDownCommandInput = setup3.children.itemById('dd_setup3')
    setup3Side = setup3dd.selectedItem.name

    setup4: adsk.core.GroupCommandInput = inputs.itemById('setup4')
    setups.append(setup4)
    setup4dd: adsk.core.DropDownCommandInput = setup4.children.itemById('dd_setup4')
    setup4Side = setup4dd.selectedItem.name

    setup5: adsk.core.GroupCommandInput = inputs.itemById('setup5')
    setups.append(setup5)
    setup5dd: adsk.core.DropDownCommandInput = setup5.children.itemById('dd_setup5')
    setup5Side = setup5dd.selectedItem.name

    setup6: adsk.core.GroupCommandInput = inputs.itemById('setup6')
    setups.append(setup6)
    setup6dd: adsk.core.DropDownCommandInput = setup6.children.itemById('dd_setup6')
    setup6Side = setup6dd.selectedItem.name

    setupP1: adsk.core.GroupCommandInput = inputs.itemById('setupP1')
    setups.append(setupP1)
    setupP1dd: adsk.core.DropDownCommandInput = setupP1.children.itemById('dd_setupP1')
    setupP1Side1 = setupP1dd.selectedItem.name

    setupP2: adsk.core.GroupCommandInput = inputs.itemById('setupP2')
    setups.append(setupP2)
    setupP2dd: adsk.core.DropDownCommandInput = setupP2.children.itemById('dd_setupP2')
    setupP2Side1 = setupP2dd.selectedItem.name

    setupP3: adsk.core.GroupCommandInput = inputs.itemById('setupP3')
    setups.append(setupP3)
    setupP3dd: adsk.core.DropDownCommandInput = setupP3.children.itemById('dd_setupP3')
    setupP3Side1 = setupP3dd.selectedItem.name

    #########Set visibility based on setups selected and pairing setting###########
    #Sets all visbility false for correct selections to be turned on later
    for i in range(len(setups)):
            setups[i].isVisible = False
    
    if setupPairing.value == True:
        for i in range(totalSetups.valueOne):
            if i == 0:
                setup1.isVisible = True
            elif i == 1:
                setup1.isVisible = False
                setupP1.isVisible = True
            elif i == 2:
                setup3.isVisible = True
            elif i == 3:
                setup3.isVisible = False
                setupP2.isVisible = True
            elif i == 4:
                setup5.isVisible = True
            else:
                setup5.isVisible = False
                setupP3.isVisible = True

    if setupPairing.value == False:
        for i in range(totalSetups.valueOne):
            setups[i].isVisible = True

    # General logging for debug.
    futil.log(f'{CMD_NAME} Input Changed Event fired from a change to {changed_input.id}')


# This event handler is called when the user interacts with any of the inputs in the dialog
# which allows you to verify that all of the inputs are valid and enables the OK button.
def command_validate_input(args: adsk.core.ValidateInputsEventArgs):
    # General logging for debug.
    futil.log(f'{CMD_NAME} Validate Input Event')

    inputs = args.inputs
    
    # Verify the validity of the input values. This controls if the OK button is enabled or not.
    valueInput = inputs.itemById('value_input')
    if valueInput.value >= 0:
        args.areInputsValid = True
    else:
        args.areInputsValid = False
        

# This event handler is called when the command terminates.
def command_destroy(args: adsk.core.CommandEventArgs):
    # General logging for debug.
    futil.log(f'{CMD_NAME} Command Destroy Event')

    global local_handlers
    local_handlers = []